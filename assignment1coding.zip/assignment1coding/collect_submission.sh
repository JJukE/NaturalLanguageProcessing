rm -f assignment1.zip
zip -r assignment1coding.zip *.py *.png saved_params_40000.npy

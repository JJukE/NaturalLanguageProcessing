rm -f assignment2.zip
zip -r assignment2coding.zip *.ipynb
